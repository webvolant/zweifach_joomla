UPDATE `#__extensions` SET `enabled` = '1' WHERE `name` = 'plg_content_foxcontact';
